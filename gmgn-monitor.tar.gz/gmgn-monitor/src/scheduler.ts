// ─────────────────────────────────────────────────────────────────────────────
//  scheduler.ts  —  Single-loop scheduler for GMGN metric fetches
//
//  Changes from v1:
//    • Each token is monitored for exactly MONITOR_WINDOW_MS (default 60 s).
//    • When the window expires the scheduler:
//        1. Waits for any in-flight request to land (pendingRequest guard).
//        2. Reads all samples for the token from the DB.
//        3. Computes and logs a full summary (first/last/min/max/avg).
//        4. Removes the token from the active set.
//    • MONITOR_INTERVAL default changed to 2 s.
//    • All other rate-limit / adaptive / priority / dedup logic unchanged.
// ─────────────────────────────────────────────────────────────────────────────

import { createLogger } from './logger';
import { GmgnClient } from './gmgn-client';
import { MonitorDatabase } from './database';
import { RateLimiter } from './rate-limiter';
import {
  BundlerMetrics,
  NewTokenEvent,
  SchedulerEntry,
  ServiceConfig,
  TokenSummary,
} from './types';

const log = createLogger('SCHED');

const SCHEDULER_TICK_MS = 500; // internal resolution — half the min interval

// ── Scheduler ─────────────────────────────────────────────────────────────────

export class Scheduler {
  private readonly entries = new Map<string, SchedulerEntry>();
  private readonly config:  ServiceConfig;
  private readonly client:  GmgnClient;
  private readonly db:      MonitorDatabase;
  private readonly limiter: RateLimiter;

  private tickTimer:   NodeJS.Timeout | null = null;
  private running      = false;
  private totalFetches = 0;

  constructor(
    config:  ServiceConfig,
    client:  GmgnClient,
    db:      MonitorDatabase,
    limiter: RateLimiter
  ) {
    this.config  = config;
    this.client  = client;
    this.db      = db;
    this.limiter = limiter;
  }

  // ── Lifecycle ──────────────────────────────────────────────────────────────

  start(): void {
    if (this.running) return;
    this.running = true;
    this.scheduleTick();
    log.info(
      `Scheduler started — interval ${this.config.monitorInterval}ms, ` +
      `window ${this.config.monitoringWindowMs}ms per token`
    );
  }

  stop(): void {
    this.running = false;
    if (this.tickTimer) {
      clearTimeout(this.tickTimer);
      this.tickTimer = null;
    }
    log.info(`Scheduler stopped — total fetches: ${this.totalFetches}`);
  }

  // ── Token management ───────────────────────────────────────────────────────

  addToken(event: NewTokenEvent): void {
    if (this.entries.has(event.mint)) return;

    const now = Date.now();
    const entry: SchedulerEntry = {
      mint:                event.mint,
      lastFetchedAt:       0,       // force immediate first fetch
      pendingRequest:      false,
      priority:            event.detectedAt,
      monitoringStartedAt: now,
    };

    this.entries.set(event.mint, entry);

    const windowSec = Math.round(this.config.monitoringWindowMs / 1_000);
    log.info(
      `Scheduler: tracking ${event.mint} for ${windowSec}s ` +
      `(${this.entries.size} active)`
    );
    this.logCapacityWarning();
  }

  removeToken(mint: string): void {
    this.entries.delete(mint);
    log.info(`Scheduler: removed ${mint} (${this.entries.size} active)`);
  }

  get activeCount(): number {
    return this.entries.size;
  }

  // ── Capacity advisory ─────────────────────────────────────────────────────

  get safeTokenCapacity(): number {
    return Math.floor(this.config.monitorInterval / this.limiter.currentDelay);
  }

  private logCapacityWarning(): void {
    const cap = this.safeTokenCapacity;
    if (this.entries.size > cap) {
      const effectiveInterval = this.entries.size * this.limiter.currentDelay;
      log.warn(
        `Token count (${this.entries.size}) exceeds safe capacity (${cap}). ` +
        `Effective poll interval stretched to ~${effectiveInterval}ms per token.`
      );
    }
  }

  // ── Scheduler tick ────────────────────────────────────────────────────────

  private scheduleTick(): void {
    if (!this.running) return;
    this.tickTimer = setTimeout(() => {
      this.tick().catch((err) => log.error('Tick error', err));
    }, SCHEDULER_TICK_MS);
  }

  private async tick(): Promise<void> {
    try {
      if (this.entries.size === 0) return;

      const now = Date.now();

      // ── 1. Expire tokens whose window has elapsed ─────────────────────────
      for (const entry of this.entries.values()) {
        const elapsed = now - entry.monitoringStartedAt;
        if (elapsed >= this.config.monitoringWindowMs && !entry.pendingRequest) {
          // Fire-and-forget the expiry so it doesn't block the tick loop
          this.expireToken(entry).catch((err) =>
            log.error(`Expiry error for ${entry.mint}`, err)
          );
        }
      }

      // ── 2. Adaptive effective interval ────────────────────────────────────
      const activeEntries = [...this.entries.values()];
      const effectiveInterval = Math.max(
        this.config.monitorInterval,
        activeEntries.length * this.limiter.currentDelay
      );

      // ── 3. Collect tokens due for a fetch ─────────────────────────────────
      const due: SchedulerEntry[] = [];
      for (const entry of activeEntries) {
        const elapsed = now - entry.monitoringStartedAt;
        if (
          !entry.pendingRequest &&
          elapsed < this.config.monitoringWindowMs &&          // still in window
          now - entry.lastFetchedAt >= effectiveInterval
        ) {
          due.push(entry);
        }
      }

      if (due.length === 0) return;

      // Sort: newest tokens (largest detectedAt) get highest priority
      due.sort((a, b) => b.priority - a.priority);

      for (const entry of due) {
        entry.pendingRequest = true;
        this.doFetch(entry).catch((err) =>
          log.error(`Unhandled fetch error for ${entry.mint}`, err)
        );
      }
    } finally {
      this.scheduleTick();
    }
  }

  // ── Window expiry + summary ───────────────────────────────────────────────

  private async expireToken(entry: SchedulerEntry): Promise<void> {
    const { mint } = entry;

    // Remove first so no more fetches are queued
    this.removeToken(mint);

    // Update DB status
    this.db.updateTokenStatus(mint, 'stopped');

    // Fetch ALL samples recorded during the window
    const samples = this.db.getLatestMetrics(mint, 10_000); // effectively all
    // getLatestMetrics returns newest-first; reverse for chronological order
    samples.reverse();

    const summary = this.buildSummary(mint, samples);
    this.logSummary(summary);
  }

  // ── Summary computation ───────────────────────────────────────────────────

  private buildSummary(mint: string, samples: BundlerMetrics[]): TokenSummary {
    const percents = samples
      .map((s) => s.bundlersPercent)
      .filter((v): v is number => v !== null);

    const counts = samples
      .map((s) => s.bundlersCount)
      .filter((v): v is number => v !== null);

    const avg = (arr: number[]): number | null =>
      arr.length === 0
        ? null
        : parseFloat((arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(4));

    return {
      mint,
      windowMs:     this.config.monitoringWindowMs,
      totalSamples: samples.length,
      firstSeen:    samples.at(0)?.timestamp  ?? new Date().toISOString(),
      lastSeen:     samples.at(-1)?.timestamp ?? new Date().toISOString(),
      bundlersPercent: {
        first: percents.at(0)  ?? null,
        last:  percents.at(-1) ?? null,
        min:   percents.length ? Math.min(...percents) : null,
        max:   percents.length ? Math.max(...percents) : null,
        avg:   avg(percents),
      },
      bundlersCount: {
        first: counts.at(0)  ?? null,
        last:  counts.at(-1) ?? null,
        min:   counts.length ? Math.min(...counts) : null,
        max:   counts.length ? Math.max(...counts) : null,
        avg:   avg(counts),
      },
    };
  }

  // ── Summary logging ───────────────────────────────────────────────────────

  private logSummary(s: TokenSummary): void {
    const windowSec = Math.round(s.windowMs / 1_000);
    const fmt = (v: number | null, suffix = ''): string =>
      v === null ? 'N/A' : `${v}${suffix}`;

    const lines = [
      ``,
      `╔══════════════════════════════════════════════════════════╗`,
      `║              [SUMMARY]  Monitoring Window Closed          ║`,
      `╠══════════════════════════════════════════════════════════╣`,
      `║  Mint    : ${s.mint}`,
      `║  Window  : ${windowSec}s   Samples: ${s.totalSamples}`,
      `║  Period  : ${s.firstSeen}  →  ${s.lastSeen}`,
      `╠══════════════════════════════════════════════════════════╣`,
      `║  Bundlers %`,
      `║    First : ${fmt(s.bundlersPercent.first, '%')}   Last : ${fmt(s.bundlersPercent.last, '%')}`,
      `║    Min   : ${fmt(s.bundlersPercent.min,   '%')}   Max  : ${fmt(s.bundlersPercent.max,  '%')}   Avg: ${fmt(s.bundlersPercent.avg, '%')}`,
      `║  Bundlers Count`,
      `║    First : ${fmt(s.bundlersCount.first)}   Last : ${fmt(s.bundlersCount.last)}`,
      `║    Min   : ${fmt(s.bundlersCount.min)}   Max  : ${fmt(s.bundlersCount.max)}   Avg: ${fmt(s.bundlersCount.avg)}`,
      `╚══════════════════════════════════════════════════════════╝`,
      ``,
    ];

    for (const line of lines) {
      log.info(line);
    }

    // Machine-readable JSON line for piping / log aggregation
    process.stdout.write(JSON.stringify({ event: 'summary', ...s }) + '\n');
  }

  // ── Fetch + persist ────────────────────────────────────────────────────────

  private async doFetch(entry: SchedulerEntry): Promise<void> {
    const { mint } = entry;

    try {
      const result = await this.client.fetchBundlerMetrics(mint);
      entry.lastFetchedAt = Date.now();
      this.totalFetches++;

      const elapsed = Math.round((Date.now() - entry.monitoringStartedAt) / 1_000);

      if (result.success) {
        const { metrics } = result;
        this.db.insertMetrics(metrics);

        log.info(
          `[MONITOR +${elapsed}s]  Mint: ${mint.slice(0, 8)}…  ` +
          `Bundlers%: ${metrics.bundlersPercent ?? 'N/A'}  ` +
          `Count: ${metrics.bundlersCount ?? 'N/A'}`,
          {
            mint,
            time:            metrics.timestamp,
            bundlersPercent: metrics.bundlersPercent,
            bundlersCount:   metrics.bundlersCount,
          }
        );

        process.stdout.write(
          JSON.stringify({
            mint,
            time:            metrics.timestamp,
            bundlersPercent: metrics.bundlersPercent,
            bundlersCount:   metrics.bundlersCount,
          }) + '\n'
        );
      } else {
        log.warn(`Fetch failed for ${mint}: ${result.error}`);

        if (result.retryAfterMs !== undefined) {
          entry.lastFetchedAt = Date.now() + result.retryAfterMs;
        }
      }
    } finally {
      entry.pendingRequest = false;
    }
  }
}
