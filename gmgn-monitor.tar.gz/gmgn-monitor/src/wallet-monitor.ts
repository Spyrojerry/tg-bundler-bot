// ─────────────────────────────────────────────────────────────────────────────
//  wallet-monitor.ts  —  Polls a Solana wallet for new SPL token holdings
//
//  On start:
//    1. Fetch all current token accounts → existingTokens set (NOT monitored)
//    2. Poll every WALLET_POLL_INTERVAL ms
//    3. Any mint not in existingTokens and not yet tracked → emit 'newToken'
// ─────────────────────────────────────────────────────────────────────────────

import {
  Connection,
  PublicKey,
  ParsedAccountData,
  TokenAccountBalancePair,
} from '@solana/web3.js';
import { EventEmitter } from 'events';
import { createLogger } from './logger';
import { NewTokenEvent, ServiceConfig, TokenHolding } from './types';

const log = createLogger('WALLET');

// ── WalletMonitor ─────────────────────────────────────────────────────────────

export class WalletMonitor extends EventEmitter {
  private readonly connection: Connection;
  private readonly walletPubkey: PublicKey;
  private readonly pollInterval: number;

  /** Mints present at startup — we ignore these */
  private existingTokens: Set<string> = new Set();

  /** All mints we've emitted a newToken event for (to avoid duplicates) */
  private knownMints: Set<string> = new Set();

  private pollTimer: NodeJS.Timeout | null = null;
  private running = false;

  constructor(config: ServiceConfig) {
    super();

    this.connection = new Connection(config.solanaRpcUrl, {
      commitment: 'confirmed',
    });

    try {
      this.walletPubkey = new PublicKey(config.walletAddress);
    } catch {
      throw new Error(`Invalid wallet address: ${config.walletAddress}`);
    }

    this.pollInterval = config.walletPollInterval;
  }

  // ── Lifecycle ──────────────────────────────────────────────────────────────

  async start(): Promise<void> {
    if (this.running) return;
    this.running = true;

    log.info(`Starting wallet monitor for ${this.walletPubkey.toBase58()}`);
    log.info(`Poll interval: ${this.pollInterval}ms`);

    // Snapshot existing holdings — these are NOT monitored
    const initial = await this.fetchHoldings();
    for (const h of initial) {
      this.existingTokens.add(h.mint);
      this.knownMints.add(h.mint);
    }

    log.info(
      `Snapshot taken: ${this.existingTokens.size} existing token(s) — these will NOT be monitored`,
      { mints: [...this.existingTokens] }
    );

    this.schedulePoll();
  }

  stop(): void {
    this.running = false;
    if (this.pollTimer) {
      clearTimeout(this.pollTimer);
      this.pollTimer = null;
    }
    log.info('Wallet monitor stopped');
  }

  // ── Snapshot accessor (for DB pre-population) ─────────────────────────────

  get existingMints(): ReadonlySet<string> {
    return this.existingTokens;
  }

  // ── Polling ───────────────────────────────────────────────────────────────

  private schedulePoll(): void {
    if (!this.running) return;
    this.pollTimer = setTimeout(() => {
      this.poll().catch((err) => log.error('Poll error', err));
    }, this.pollInterval);
  }

  private async poll(): Promise<void> {
    try {
      const holdings = await this.fetchHoldings();
      const now = Date.now();

      for (const h of holdings) {
        if (!this.knownMints.has(h.mint)) {
          this.knownMints.add(h.mint);

          // Skip zero-balance tokens (often airdrop dust)
          if (h.uiAmount === 0) {
            log.debug(`Skipping zero-balance new mint ${h.mint}`);
            continue;
          }

          log.info(`[NEW TOKEN] Mint: ${h.mint}  Amount: ${h.uiAmount ?? h.amount}`);

          const event: NewTokenEvent = { mint: h.mint, detectedAt: now };
          this.emit('newToken', event);
        }
      }
    } catch (err) {
      log.error('Failed to poll wallet holdings', err);
    } finally {
      this.schedulePoll();
    }
  }

  // ── RPC: fetch SPL token accounts ─────────────────────────────────────────

  private async fetchHoldings(): Promise<TokenHolding[]> {
    const resp = await this.connection.getParsedTokenAccountsByOwner(
      this.walletPubkey,
      { programId: new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA') },
      'confirmed'
    );

    const holdings: TokenHolding[] = [];

    for (const { account } of resp.value) {
      const parsedData = account.data as ParsedAccountData;
      const info = parsedData?.parsed?.info as {
        mint: string;
        tokenAmount: TokenAccountBalancePair;
      } | undefined;

      if (!info?.mint) continue;

      holdings.push({
        mint: info.mint,
        amount: info.tokenAmount.amount,
        decimals: info.tokenAmount.decimals,
        uiAmount: info.tokenAmount.uiAmount,
      });
    }

    return holdings;
  }
}
