// ─────────────────────────────────────────────────────────────────────────────
//  gmgn-client.ts  —  GMGN OpenAPI REST client
//
//  Bundler data comes from two endpoints:
//    1.  GET /token/security?chain=sol&address=<mint>
//        Fields: bundler_trader_amount_rate, bundle_num / bundler_count
//
//    2.  GET /token/info?chain=sol&address=<mint>   (fallback)
//        Some GMGN plan tiers surface bundler fields here instead.
//
//  Authentication: GMGN_API_KEY sent as  X-API-KEY  header.
//  (Ed25519 signing is only required for swap/order endpoints.)
//
//  Rate limits: Not published. Community observation ~2 req/s.
//  We rely on RateLimiter for all throttling — this module just fires requests.
// ─────────────────────────────────────────────────────────────────────────────

import { createLogger } from './logger';
import { RateLimiter } from './rate-limiter';
import {
  BundlerMetrics,
  FetchResult,
  GmgnSecurityResponse,
  ServiceConfig,
} from './types';

const log = createLogger('GMGN');

// ── Retry config ──────────────────────────────────────────────────────────────

const MAX_RETRIES      = 3;
const BASE_RETRY_MS    = 1_000;
const REQUEST_TIMEOUT  = 15_000;  // ms

// ── Helper: sleep ─────────────────────────────────────────────────────────────

const sleep = (ms: number): Promise<void> =>
  new Promise((r) => setTimeout(r, ms));

// ── GmgnClient ────────────────────────────────────────────────────────────────

export class GmgnClient {
  private readonly baseUrl: string;
  private readonly apiKey:  string;
  private readonly chain  = 'sol';
  private readonly limiter: RateLimiter;
  private readonly baselineMinTime: number;

  constructor(config: ServiceConfig, limiter: RateLimiter) {
    this.baseUrl          = config.gmgnApiBaseUrl.replace(/\/$/, '');
    this.apiKey           = config.gmgnApiKey;
    this.limiter          = limiter;
    this.baselineMinTime  = config.rateLimitMinTime;
  }

  // ── Public: fetch bundler metrics for one token ───────────────────────────

  async fetchBundlerMetrics(mint: string): Promise<FetchResult> {
    // Try /token/security first; fall back to /token/info
    for (const endpoint of ['token/security', 'token/info']) {
      const result = await this.fetchWithRetry(endpoint, mint);
      if (result.success) return result;

      // If it was a 429 or a network error, abort (don't try fallback)
      if (!result.success && result.retryAfterMs !== undefined) {
        return result;
      }
    }

    return { success: false, error: 'All GMGN endpoints failed' };
  }

  // ── Internal: fetch with retry ────────────────────────────────────────────

  private async fetchWithRetry(
    endpoint: string,
    mint: string
  ): Promise<FetchResult> {
    let lastError = '';

    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
      if (attempt > 0) {
        const delay = BASE_RETRY_MS * 2 ** (attempt - 1);
        log.debug(`Retry ${attempt}/${MAX_RETRIES} for ${mint} in ${delay}ms`);
        await sleep(delay);
      }

      const result = await this.limiter.schedule(() =>
        this.doRequest(endpoint, mint)
      );

      if (result.success) {
        this.limiter.onSuccess(this.baselineMinTime);
        return result;
      }

      lastError = result.error;

      // 429 → activate backoff but don't retry here (scheduler will reschedule)
      if (result.retryAfterMs !== undefined) {
        this.limiter.onRateLimited(result.retryAfterMs);
        return result;
      }
    }

    return { success: false, error: lastError };
  }

  // ── Internal: single HTTP request ─────────────────────────────────────────

  private async doRequest(
    endpoint: string,
    mint: string
  ): Promise<FetchResult> {
    const url = `${this.baseUrl}/${endpoint}?chain=${this.chain}&address=${mint}`;

    log.debug(`GET ${url}`);

    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT);

      const resp = await fetch(url, {
        method: 'GET',
        headers: {
          'X-API-KEY': this.apiKey,
          Accept: 'application/json',
          'User-Agent': 'gmgn-monitor/1.0',
        },
        signal: controller.signal,
      });

      clearTimeout(timer);

      // ── 429 Too Many Requests ─────────────────────────────────────────────
      if (resp.status === 429) {
        const retryAfter = resp.headers.get('Retry-After');
        const retryMs = retryAfter
          ? parseInt(retryAfter, 10) * 1_000
          : undefined;
        return {
          success: false,
          error: 'Rate limited (429)',
          retryAfterMs: retryMs,
        };
      }

      // ── Other HTTP errors ─────────────────────────────────────────────────
      if (!resp.ok) {
        const body = await resp.text().catch(() => '');
        log.warn(`HTTP ${resp.status} from ${endpoint}`, { body: body.slice(0, 200) });
        return { success: false, error: `HTTP ${resp.status}` };
      }

      // ── Parse JSON ────────────────────────────────────────────────────────
      const json = (await resp.json()) as GmgnSecurityResponse;

      if (json.code !== 0) {
        return { success: false, error: `GMGN error: ${json.msg}` };
      }

      if (!json.data) {
        return { success: false, error: 'Empty data payload' };
      }

      return { success: true, metrics: this.parseMetrics(mint, json) };

    } catch (err: unknown) {
      if (err instanceof Error && err.name === 'AbortError') {
        return { success: false, error: `Request timeout after ${REQUEST_TIMEOUT}ms` };
      }
      return { success: false, error: String(err) };
    }
  }

  // ── Internal: extract bundler fields from raw API response ────────────────

  private parseMetrics(
    mint: string,
    json: GmgnSecurityResponse
  ): BundlerMetrics {
    const d = json.data ?? {};

    // bundler percentage (the API gives a 0–1 rate, we convert to 0–100 %)
    const rawRate =
      (d.bundler_trader_amount_rate as number | undefined) ??
      (d.bundled_amount_rate      as number | undefined) ??
      null;
    const bundlersPercent =
      rawRate !== null ? parseFloat((rawRate * 100).toFixed(4)) : null;

    // bundler count
    const bundlersCount =
      (d.bundle_num      as number | undefined) ??
      (d.bundler_count   as number | undefined) ??
      null;

    return {
      mint,
      timestamp: new Date().toISOString(),
      bundlersPercent,
      bundlersCount: bundlersCount !== null ? Math.round(bundlersCount) : null,
      bundledAmountRate: rawRate,
      rawData: JSON.stringify(d),
    };
  }
}
