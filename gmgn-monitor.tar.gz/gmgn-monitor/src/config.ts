// ─────────────────────────────────────────────────────────────────────────────
//  config.ts  —  Load and validate all environment variables at startup
// ─────────────────────────────────────────────────────────────────────────────

import { ServiceConfig } from './types';

function required(key: string): string {
  const val = process.env[key];
  if (!val || val.trim() === '') {
    throw new Error(`Missing required environment variable: ${key}`);
  }
  return val.trim();
}

function optional(key: string, defaultVal: string): string {
  return process.env[key]?.trim() || defaultVal;
}

function optionalInt(key: string, defaultVal: number): number {
  const raw = process.env[key]?.trim();
  if (!raw) return defaultVal;
  const n = parseInt(raw, 10);
  if (isNaN(n) || n <= 0) {
    throw new Error(`${key} must be a positive integer, got: ${raw}`);
  }
  return n;
}

function isValidLogLevel(s: string): s is ServiceConfig['logLevel'] {
  return ['debug', 'info', 'warn', 'error'].includes(s);
}

export function loadConfig(): ServiceConfig {
  const walletAddress    = required('WALLET_ADDRESS');
  const gmgnApiKey       = required('GMGN_API_KEY');
  const solanaRpcUrl     = optional('SOLANA_RPC_URL', 'https://api.mainnet-beta.solana.com');
  const gmgnApiBaseUrl   = optional('GMGN_API_BASE_URL', 'https://gmgn.ai/api/v1');
  const dbPath           = optional('DB_PATH', './data/monitor.db');
  const rawLogLevel      = optional('LOG_LEVEL', 'info');

  const walletPollInterval     = optionalInt('WALLET_POLL_INTERVAL', 5_000);
  const monitorInterval        = optionalInt('MONITOR_INTERVAL', 2_000);
  const monitoringWindowMs     = optionalInt('MONITOR_WINDOW_MS', 60_000);
  const rateLimitMinTime       = optionalInt('RATE_LIMIT_MIN_TIME', 500);
  const rateLimitMaxConcurrent = optionalInt('RATE_LIMIT_MAX_CONCURRENT', 1);

  if (!isValidLogLevel(rawLogLevel)) {
    throw new Error(`LOG_LEVEL must be one of debug|info|warn|error, got: ${rawLogLevel}`);
  }

  // Sanity checks
  if (monitorInterval < 1_000) {
    throw new Error('MONITOR_INTERVAL must be at least 1000ms');
  }
  if (rateLimitMinTime < 100) {
    throw new Error('RATE_LIMIT_MIN_TIME must be at least 100ms (do not exceed API rate limits)');
  }
  if (monitoringWindowMs < monitorInterval) {
    throw new Error('MONITOR_WINDOW_MS must be >= MONITOR_INTERVAL');
  }

  return {
    walletAddress,
    solanaRpcUrl,
    walletPollInterval,
    gmgnApiKey,
    gmgnApiBaseUrl,
    monitorInterval,
    monitoringWindowMs,
    rateLimitMinTime,
    rateLimitMaxConcurrent,
    dbPath,
    logLevel: rawLogLevel,
  };
}
