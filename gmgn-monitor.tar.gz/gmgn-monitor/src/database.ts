// ─────────────────────────────────────────────────────────────────────────────
//  database.ts  —  SQLite persistence via better-sqlite3
// ─────────────────────────────────────────────────────────────────────────────

import Database from 'better-sqlite3';
import * as fs from 'fs';
import * as path from 'path';
import { BundlerMetrics, MonitoringStatus, TrackedToken } from './types';
import { createLogger } from './logger';

const log = createLogger('DB');

// ── Schema ────────────────────────────────────────────────────────────────────

const SCHEMA = `
PRAGMA journal_mode = WAL;
PRAGMA synchronous   = NORMAL;
PRAGMA foreign_keys  = ON;

CREATE TABLE IF NOT EXISTS tokens (
  mint               TEXT    PRIMARY KEY NOT NULL,
  first_seen         TEXT    NOT NULL,
  monitoring_status  TEXT    NOT NULL DEFAULT 'active',
  detected_at_ms     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS bundler_metrics (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  mint                 TEXT    NOT NULL,
  timestamp            TEXT    NOT NULL,
  bundlers_percent     REAL,
  bundlers_count       INTEGER,
  bundled_amount_rate  REAL,
  raw_data             TEXT,
  FOREIGN KEY (mint) REFERENCES tokens(mint) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_bundler_metrics_mint      ON bundler_metrics(mint);
CREATE INDEX IF NOT EXISTS idx_bundler_metrics_timestamp ON bundler_metrics(timestamp);
`;

// ── DB wrapper ────────────────────────────────────────────────────────────────

export class MonitorDatabase {
  private db: Database.Database;

  constructor(dbPath: string) {
    const dir = path.dirname(dbPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    this.db = new Database(dbPath);
    this.db.exec(SCHEMA);
    log.info(`Database ready at ${path.resolve(dbPath)}`);
  }

  // ── tokens table ───────────────────────────────────────────────────────────

  insertToken(token: TrackedToken): void {
    this.db
      .prepare(
        `INSERT OR IGNORE INTO tokens (mint, first_seen, monitoring_status, detected_at_ms)
         VALUES (@mint, @firstSeen, @monitoringStatus, @detectedAt)`
      )
      .run({
        mint: token.mint,
        firstSeen: token.firstSeen,
        monitoringStatus: token.monitoringStatus,
        detectedAt: token.detectedAt,
      });
  }

  updateTokenStatus(mint: string, status: MonitoringStatus): void {
    this.db
      .prepare(`UPDATE tokens SET monitoring_status = ? WHERE mint = ?`)
      .run(status, mint);
  }

  getAllActiveTokens(): TrackedToken[] {
    const rows = this.db
      .prepare(`SELECT * FROM tokens WHERE monitoring_status = 'active'`)
      .all() as Array<{
        mint: string;
        first_seen: string;
        monitoring_status: string;
        detected_at_ms: number;
      }>;

    return rows.map((r) => ({
      mint: r.mint,
      firstSeen: r.first_seen,
      monitoringStatus: r.monitoring_status as MonitoringStatus,
      detectedAt: r.detected_at_ms,
    }));
  }

  tokenExists(mint: string): boolean {
    const row = this.db
      .prepare(`SELECT 1 FROM tokens WHERE mint = ?`)
      .get(mint);
    return row !== undefined;
  }

  // ── bundler_metrics table ──────────────────────────────────────────────────

  insertMetrics(m: BundlerMetrics): void {
    this.db
      .prepare(
        `INSERT INTO bundler_metrics
           (mint, timestamp, bundlers_percent, bundlers_count, bundled_amount_rate, raw_data)
         VALUES
           (@mint, @timestamp, @bundlersPercent, @bundlersCount, @bundledAmountRate, @rawData)`
      )
      .run({
        mint: m.mint,
        timestamp: m.timestamp,
        bundlersPercent: m.bundlersPercent ?? null,
        bundlersCount: m.bundlersCount ?? null,
        bundledAmountRate: m.bundledAmountRate ?? null,
        rawData: m.rawData ?? null,
      });
  }

  getLatestMetrics(mint: string, limit = 10): BundlerMetrics[] {
    const rows = this.db
      .prepare(
        `SELECT * FROM bundler_metrics WHERE mint = ?
         ORDER BY timestamp DESC LIMIT ?`
      )
      .all(mint, limit) as Array<{
        id: number;
        mint: string;
        timestamp: string;
        bundlers_percent: number | null;
        bundlers_count: number | null;
        bundled_amount_rate: number | null;
        raw_data: string | null;
      }>;

    return rows.map((r) => ({
      id: r.id,
      mint: r.mint,
      timestamp: r.timestamp,
      bundlersPercent: r.bundlers_percent,
      bundlersCount: r.bundlers_count,
      bundledAmountRate: r.bundled_amount_rate,
      rawData: r.raw_data ?? undefined,
    }));
  }

  metricsCount(mint: string): number {
    const row = this.db
      .prepare(`SELECT COUNT(*) as cnt FROM bundler_metrics WHERE mint = ?`)
      .get(mint) as { cnt: number };
    return row.cnt;
  }

  close(): void {
    this.db.close();
    log.info('Database connection closed');
  }
}
