// ─────────────────────────────────────────────────────────────────────────────
//  types.ts  —  Shared TypeScript types for the GMGN monitor service
// ─────────────────────────────────────────────────────────────────────────────

/** Status of a token in our monitoring pipeline */
export type MonitoringStatus = 'active' | 'paused' | 'stopped';

/** A token we are (or were) monitoring */
export interface TrackedToken {
  mint: string;
  firstSeen: string;          // ISO-8601 UTC
  monitoringStatus: MonitoringStatus;
  detectedAt: number;         // performance.now() epoch for priority scoring
}

/** One sample of GMGN bundler metrics */
export interface BundlerMetrics {
  id?: number;                // assigned by SQLite on insert
  mint: string;
  timestamp: string;          // ISO-8601 UTC
  bundlersPercent: number | null;   // bundler_trader_amount_rate × 100
  bundlersCount: number | null;     // bundle_num / bundler_count
  bundledAmountRate: number | null; // raw rate (0-1) from API
  // Any extra fields the API returns — stored as JSON string in DB
  rawData?: string;
}

/** Raw token-security response shape from GMGN OpenAPI */
export interface GmgnSecurityResponse {
  code: number;
  msg: string;
  data?: {
    // Known bundler fields — names may vary; we handle both spellings
    bundler_trader_amount_rate?: number;   // fraction 0–1
    bundle_num?: number;                   // count of bundler wallets
    bundler_count?: number;                // alternative field name
    bundled_amount_rate?: number;          // alternative rate field
    // Other security fields (we capture but don't require them)
    [key: string]: unknown;
  };
}

/** Wallet token holding (from @solana/web3.js parsed account) */
export interface TokenHolding {
  mint: string;
  amount: string;    // raw token amount as string
  decimals: number;
  uiAmount: number | null;
}

/** Scheduler tick entry */
export interface SchedulerEntry {
  mint: string;
  lastFetchedAt: number;       // ms timestamp of last completed fetch
  pendingRequest: boolean;     // guard against duplicate in-flight requests
  priority: number;            // lower = higher priority (ms since detection)
  monitoringStartedAt: number; // ms timestamp when this token was added
}

/** Summary emitted after a token's monitoring window expires */
export interface TokenSummary {
  mint: string;
  windowMs: number;
  totalSamples: number;
  firstSeen: string;          // ISO-8601 UTC
  lastSeen: string;           // ISO-8601 UTC
  bundlersPercent: {
    first:   number | null;
    last:    number | null;
    min:     number | null;
    max:     number | null;
    avg:     number | null;
  };
  bundlersCount: {
    first:   number | null;
    last:    number | null;
    min:     number | null;
    max:     number | null;
    avg:     number | null;
  };
}

/** Config pulled from environment variables (all validated at startup) */
export interface ServiceConfig {
  walletAddress: string;
  solanaRpcUrl: string;
  walletPollInterval: number;
  gmgnApiKey: string;
  gmgnApiBaseUrl: string;
  monitorInterval: number;
  monitoringWindowMs: number;  // how long to monitor each token before summarising
  rateLimitMinTime: number;
  rateLimitMaxConcurrent: number;
  dbPath: string;
  logLevel: 'debug' | 'info' | 'warn' | 'error';
}

/** Internal event types emitted between modules */
export interface NewTokenEvent {
  mint: string;
  detectedAt: number;
}

/** Result of a single GMGN fetch attempt */
export type FetchResult =
  | { success: true;  metrics: BundlerMetrics }
  | { success: false; error: string; retryAfterMs?: number };
